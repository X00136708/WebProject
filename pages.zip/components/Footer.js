const Footer = () => (
<div>
	<p>Page footer</p>
</div>

)
export default Footer;