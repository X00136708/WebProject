import React, { Components } from 'react';


export default class SearchForm extends Components {

	constructor(props) {
		super(props);

		this.state = {
		};

	}



	formSubmitted = (event) => {
	if (event.target.newsSource.value != "") {
		this.props.setNewsSource(event.target.newsSource.value);
	}



	event.preventDefault();

	}



	render() {

		return (

			<div>


				<div id="search">

					<h3>Enter newsapi.org source</h3>
					<form onSubmit={this.formSubmitted}>
						<input name="newsSource" placeholder="News Source name" type="text" />
						<button>Update News</button>
					</form>

				</div>

			</div>

		);

	}

}