import Link from 'next/link'
const Nav = () => ( 
<div>
	<ul>
		<li>
			<Link href="/index">
				<a>Home</a>
			</Link>
		</li>
		<li>
			<Link href="/about">
				<a>About</a>
			</Link>
		</li>
	</ul>
</div>
)
export default Nav;
