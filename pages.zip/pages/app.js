import App, { Container } from 'next/app';
import Page from '../components/Page';
// Define the custom App - a class which extents the default App
class MyApp extends App {
 render() {
 // Compent will be the page content
 // e.g. index or about
 const {Component} = this.props;
 return (
 // Container contains page content
 <Container>
 {/* Content which will be shared */}
<Page>
 {/* Compontent is page e.g. index or about */}
 <Component/>
 </Page>
 </Container>
 );
 }
}
export default MyApp;