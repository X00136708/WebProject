import Link from 'next/link'
import fetch from 'isomorphic-unfetch';
import Layout from '../components/style.js';
import Meta from '../components/Meta';
import React, {Component} from 'react';
	const source = 'the-irish-times';
	const apiKey = '3780066b33ef41b9b4b7e957994e9c38';
	const url = `https://newsapi.org/v2/top-headlines?sources=${source}&apikey=${apiKey}`;
	
	const News = props => (
	
		<Layout>
			

  
<ul>
  <li><a onclick= "news('the-irish-times')" >Irish times</a></li>
  <li><a onclick= "news('abc-news')">ABC News</a></li>
  <li><a onclick= "news('bbc-news')">BBC News</a></li>
</ul>			
		

			<h2>News from {source.split("-").join(" ")}</h2>
			
			<div>

				{props.articles.map(article => (
					<section>
						
						<h3>{article.title}</h3>
						<p className="author">{article.author} {article.publishedAt}</p>
						<img src = {article.urlToImage} alt = "article image" className="img-article"></img>
						<p>{article.description}</p>
						<p><Link hres="/story">Read more</Link></p>
						
					</section>
				))}
				</div>
				
			
				
				<style jsx>{`
						h2{
							color: red;
						}
						p{
							color: blue;
						}

						
					`}

					</style>
				</Layout>
				
		);

	News.getInitialProps = async function(){
		const res = await fetch(url);
		const data = await res.json();
		

		return {
			articles: data.articles
		}
	}
		export default News;